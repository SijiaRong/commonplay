# 泡泡星港：景观模型生成参考库

16 个独立资产；每个包含 1 张四视图设计板及 4 张独立白底 PNG。图像由内置 image_gen 生成。

## 文件与视角

- `reference-sheet.png`：设计审阅用，左上正面、右上右侧、左下背面、右下斜视。
- `front.png`、`right.png`、`back.png`、`three-quarter.png`：从设计板原样拆出的独立视图，去掉网格线并补白成方图；未放大或重画。
- `manifest.json`：包含各资产描述、完整生成提示词、源文件、视图路径及像素尺寸。

## 用于 Hi3D

1. 每次只提交一个资产。选择独立单视图，不要把四视图设计板当作一张物体照片提交。
2. 以 `front.png` 为正面参考；斜视图适合检查整体体积。其他视图需按当时接口支持的视角和数量填写，不能把右侧当左侧。
3. 同一资产的四视图应一起核对：这些是 AI 概念参考，不是经过尺寸校准的同一网格渲染；细节若冲突，以正面和斜视图确认的主体造型为准。
4. 当前只制作 2D 参考，未发起 Hi3D 3D 生成，也未验证重建质量。

## 建模边界

- 保留奶油白、薄荷绿、蜜桃色及玩具模型材质；隐藏背面为保守设计补全。
- 赛道、障碍、赛道支架、底座、房间和地面不包含在本资产库中。门架仅为独立装饰结构。
- 建筑按闭合外壳设计，透明玻璃和内部摆件仅为造型参考；后续需检查背面、薄壁、底面及材质。
- 摩天轮先按静态景观整体建模；需要动画时，轮体、支架与吊舱要在 DCC 软件中拆分。
- 机器人为中性 A 姿势参考；参考图不代表已有骨骼或动画。
- 弧形商铺为独立填充模块，尺寸和曲率需按实际赛道重新适配。
- 桌伞为连接的整体；咖啡椅独立。花箱包含植物，小树包含花盆。
- 发光、玻璃折射、金属效果在引擎中重新配置。窗框、栏杆、树叶等细节可能需要简化。

## 资产目录

| 编号 | 模型 | 设计板 | 独立视图 |
|---|---|---|---|
| 01 | 土星地标 | [四视图](01-saturn-landmark/reference-sheet.png) | [正面](01-saturn-landmark/front.png) · [右侧](01-saturn-landmark/right.png) · [背面](01-saturn-landmark/back.png) · [斜视](01-saturn-landmark/three-quarter.png) |
| 02 | 摩天轮 | [四视图](02-ferris-wheel/reference-sheet.png) | [正面](02-ferris-wheel/front.png) · [右侧](02-ferris-wheel/right.png) · [背面](02-ferris-wheel/back.png) · [斜视](02-ferris-wheel/three-quarter.png) |
| 03 | 汽水店 | [四视图](03-soda-cafe/reference-sheet.png) | [正面](03-soda-cafe/front.png) · [右侧](03-soda-cafe/right.png) · [背面](03-soda-cafe/back.png) · [斜视](03-soda-cafe/three-quarter.png) |
| 04 | 月牙观测塔 | [四视图](04-moon-observatory/reference-sheet.png) | [正面](04-moon-observatory/front.png) · [右侧](04-moon-observatory/right.png) · [背面](04-moon-observatory/back.png) · [斜视](04-moon-observatory/three-quarter.png) |
| 05 | 玻璃穹顶馆 | [四视图](05-glass-dome-pavilion/reference-sheet.png) | [正面](05-glass-dome-pavilion/front.png) · [右侧](05-glass-dome-pavilion/right.png) · [背面](05-glass-dome-pavilion/back.png) · [斜视](05-glass-dome-pavilion/three-quarter.png) |
| 06 | 弧形商铺模块 | [四视图](06-curved-shop/reference-sheet.png) | [正面](06-curved-shop/front.png) · [右侧](06-curved-shop/right.png) · [背面](06-curved-shop/back.png) · [斜视](06-curved-shop/three-quarter.png) |
| 07 | 终点站房 | [四视图](07-terminal-station/reference-sheet.png) | [正面](07-terminal-station/front.png) · [右侧](07-terminal-station/right.png) · [背面](07-terminal-station/back.png) · [斜视](07-terminal-station/three-quarter.png) |
| 08 | 服务机器人 | [四视图](08-service-robot/reference-sheet.png) | [正面](08-service-robot/front.png) · [右侧](08-service-robot/right.png) · [背面](08-service-robot/back.png) · [斜视](08-service-robot/three-quarter.png) |
| 09 | 长椅 | [四视图](09-bench/reference-sheet.png) | [正面](09-bench/front.png) · [右侧](09-bench/right.png) · [背面](09-bench/back.png) · [斜视](09-bench/three-quarter.png) |
| 10 | 路灯 | [四视图](10-lamp/reference-sheet.png) | [正面](10-lamp/front.png) · [右侧](10-lamp/right.png) · [背面](10-lamp/back.png) · [斜视](10-lamp/three-quarter.png) |
| 11 | 花箱 | [四视图](11-planter/reference-sheet.png) | [正面](11-planter/front.png) · [右侧](11-planter/right.png) · [背面](11-planter/back.png) · [斜视](11-planter/three-quarter.png) |
| 12 | 遮阳伞桌 | [四视图](12-umbrella-table/reference-sheet.png) | [正面](12-umbrella-table/front.png) · [右侧](12-umbrella-table/right.png) · [背面](12-umbrella-table/back.png) · [斜视](12-umbrella-table/three-quarter.png) |
| 13 | 咖啡椅 | [四视图](13-cafe-chair/reference-sheet.png) | [正面](13-cafe-chair/front.png) · [右侧](13-cafe-chair/right.png) · [背面](13-cafe-chair/back.png) · [斜视](13-cafe-chair/three-quarter.png) |
| 14 | 火箭装饰门架 | [四视图](14-rocket-gantry/reference-sheet.png) | [正面](14-rocket-gantry/front.png) · [右侧](14-rocket-gantry/right.png) · [背面](14-rocket-gantry/back.png) · [斜视](14-rocket-gantry/three-quarter.png) |
| 15 | 观赏小树 | [四视图](15-ornamental-tree/reference-sheet.png) | [正面](15-ornamental-tree/front.png) · [右侧](15-ornamental-tree/right.png) · [背面](15-ornamental-tree/back.png) · [斜视](15-ornamental-tree/three-quarter.png) |
| 16 | 广场围栏 | [四视图](16-plaza-railing/reference-sheet.png) | [正面](16-plaza-railing/front.png) · [右侧](16-plaza-railing/right.png) · [背面](16-plaza-railing/back.png) · [斜视](16-plaza-railing/three-quarter.png) |

## 完整提示词

每个资产的完整英文提示词已保存在 `manifest.json` 的 `generation_prompt` 中，可继续迭代。
