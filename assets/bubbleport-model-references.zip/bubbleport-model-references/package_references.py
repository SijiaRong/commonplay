"""Copy generated sheets and extract their four existing views using macOS sips."""
from pathlib import Path
import json
import shutil
import struct
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / 'manifest.json').read_text())
views = [('front', 0, 0), ('right', 1, 0), ('back', 0, 1), ('three-quarter', 1, 1)]
for asset in manifest['assets']:
    sheet = ROOT / asset['sheet']
    sheet.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(asset['source_sheet'], sheet)
    with sheet.open('rb') as stream:
        header = stream.read(24)
    width, height = struct.unpack('>II', header[16:24])
    assert width % 2 == 0 and height % 2 == 0
    cell_w, cell_h = width // 2, height // 2
    inset = 6
    crop_w, crop_h = cell_w - inset * 2, cell_h - inset * 2
    side = max(crop_w, crop_h)
    asset['sheet_dimensions'] = [width, height]
    asset['view_dimensions'] = [side, side]
    for name, col, row in views:
        output = ROOT / asset['views'][name]
        subprocess.run(['sips', '-c', str(crop_h), str(crop_w), '--cropOffset', str(row * cell_h + inset), str(col * cell_w + inset), str(sheet), '--out', str(output)], check=True, capture_output=True)
        subprocess.run(['sips', '-p', str(side), str(side), '--padColor', 'FFFFFF', str(output), '--out', str(output)], check=True, capture_output=True)
    print(asset['id'], f'{width}x{height}', '4 views', f'{side}x{side}')
(ROOT / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')

lines = ['# 泡泡星港：景观模型生成参考库', '', '16 个独立资产；每个包含 1 张四视图设计板及 4 张独立白底 PNG。图像由内置 image_gen 生成。', '', '## 文件与视角', '', '- `reference-sheet.png`：设计审阅用，左上正面、右上右侧、左下背面、右下斜视。', '- `front.png`、`right.png`、`back.png`、`three-quarter.png`：从设计板原样拆出的独立视图，去掉网格线并补白成方图；未放大或重画。', '- `manifest.json`：包含各资产描述、完整生成提示词、源文件、视图路径及像素尺寸。', '', '## 用于 Hi3D', '', '1. 每次只提交一个资产。选择独立单视图，不要把四视图设计板当作一张物体照片提交。', '2. 以 `front.png` 为正面参考；斜视图适合检查整体体积。其他视图需按当时接口支持的视角和数量填写，不能把右侧当左侧。', '3. 同一资产的四视图应一起核对：这些是 AI 概念参考，不是经过尺寸校准的同一网格渲染；细节若冲突，以正面和斜视图确认的主体造型为准。', '4. 当前只制作 2D 参考，未发起 Hi3D 3D 生成，也未验证重建质量。', '', '## 建模边界', '', '- 保留奶油白、薄荷绿、蜜桃色及玩具模型材质；隐藏背面为保守设计补全。', '- 赛道、障碍、赛道支架、底座、房间和地面不包含在本资产库中。门架仅为独立装饰结构。', '- 建筑按闭合外壳设计，透明玻璃和内部摆件仅为造型参考；后续需检查背面、薄壁、底面及材质。', '- 摩天轮先按静态景观整体建模；需要动画时，轮体、支架与吊舱要在 DCC 软件中拆分。', '- 机器人为中性 A 姿势参考；参考图不代表已有骨骼或动画。', '- 弧形商铺为独立填充模块，尺寸和曲率需按实际赛道重新适配。', '- 桌伞为连接的整体；咖啡椅独立。花箱包含植物，小树包含花盆。', '- 发光、玻璃折射、金属效果在引擎中重新配置。窗框、栏杆、树叶等细节可能需要简化。', '', '## 资产目录', '', '| 编号 | 模型 | 设计板 | 独立视图 |', '|---|---|---|---|']
for a in manifest['assets']:
    links = ' · '.join(f'[{label}]({a["views"][key]})' for key, label in [('front', '正面'), ('right', '右侧'), ('back', '背面'), ('three-quarter', '斜视')])
    lines.append(f'| {a["id"].split("-")[0]} | {a["name"]} | [四视图]({a["sheet"]}) | {links} |')
lines += ['', '## 完整提示词', '', '每个资产的完整英文提示词已保存在 `manifest.json` 的 `generation_prompt` 中，可继续迭代。', '']
(ROOT / 'README.md').write_text('\n'.join(lines))
archive = ROOT.parent / 'bubbleport-model-references.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as bundle:
    for file in sorted(ROOT.rglob('*')):
        if file.is_file():
            bundle.write(file, Path(ROOT.name) / file.relative_to(ROOT))
print('Archive:', archive, archive.stat().st_size)
